
public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileIO a1 = new FileIO("Z:\\JavaPrograms2\\assignment336b\\src\\Salesdat.txt");
		Franchise f = a1.readData();
	}

}
