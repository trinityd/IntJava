//Friend Trinity Dickinson
//CIS 36B-61Y
//Professor Singh
//Assignment 2, Part 2
//Due: 10/20/2017

import java.lang.*;
import java.util.*;

public class Driver {
	public static void main(String[] args) {
		Coin coin = new Coin();
		Simulation sim1 = new Simulation();
		sim1.simulate(coin, 20);
	}
}