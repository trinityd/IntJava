//Friend Trinity Dickinson
//CIS 36B-61Y
//Professor Singh
//Assignment 2, Part 2
//Due: 10/20/2017

import java.lang.*;
import java.util.*;

public class Assignment2Part2 {
	public static void main(String[] args) {
		Coin coin = new Coin();
		coin.toss20Times();
	}
}