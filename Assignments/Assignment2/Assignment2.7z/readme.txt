Friend Trinity Dickinson
CIS 36B-61Y, Professor Singh
Assignment 2
Due: 10/20/2017

Part 1:
	Run the program, input what's requested in the console, the classes will be instantiated, and their variables will be output to the console.

Part 2:
	Run the program. The results and overall count of 20 flips will be displayed.