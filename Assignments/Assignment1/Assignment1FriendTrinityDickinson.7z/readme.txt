Friend Trinity Dickinson
CIS 36B-61Y, Professor Singh
Assignment 1
Due: 10/8/2017

Part 1:
	Run the program, input what's requested in the console (without picking a number that would overflow or picking a negative number, I didn't add error checking. Do we need error checking?), and the resulting loan information will be output to the console.

Part 2:
	Run the program, input a number as requested, and the approximate square root will be output to the console.